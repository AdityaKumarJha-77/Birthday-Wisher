function updateName() {
  const name = document.getElementById("nameInput").value;
  if (name) {
    document.querySelector("h1").textContent = `🎂 Happy Birthday ${name}! 🎉`;
  }
}

function downloadCard() {
  html2canvas(document.querySelector(".card")).then(canvas => {
    const link = document.createElement("a");
    link.download = "birthday-card.png";
    link.href = canvas.toDataURL("image/png");
    link.click();
  });
}
